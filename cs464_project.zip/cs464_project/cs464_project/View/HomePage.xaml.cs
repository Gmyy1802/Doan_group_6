﻿using cs464_project.View_Body;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace cs464_project.View
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        public HomePage()
        {
            InitializeComponent();
        }
        private void Menu_QuanLy_Click(object sender, RoutedEventArgs e)
        {

        }

      
        private void Menu_HeThong_Click(object sender, RoutedEventArgs e)
        {
            HeThong w = new HeThong();
            w.Show();
            this.Close(); // hoặc Hide()
        }

        private void Menu_ThongKe_Click(object sender, RoutedEventArgs e)
        {
            ThongKe w = new ThongKe();
            w.Show();
            this.Close();
        }

        private void Menu_TroGiup_Click(object sender, RoutedEventArgs e)
        {
            TroGiup w = new TroGiup();
            w.Show();
            this.Close();
        }


        private void Menu_SanPham_Click(object sender, RoutedEventArgs e)
        {
            QuanLySanPham w = new QuanLySanPham();
            w.Show();
            this.Close();
        }

        private void Menu_NhanVien_Click(object sender, RoutedEventArgs e)
        {
            QuanLyNhanVien w = new QuanLyNhanVien();
            w.Show();
            this.Close();
        }

        private void Menu_HoaDon_Click(object sender, RoutedEventArgs e)
        {
            QuanLyHoaDon w = new QuanLyHoaDon();
            w.Show();
            this.Close();
        }
    }
}
